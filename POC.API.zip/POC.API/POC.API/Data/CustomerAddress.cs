﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace POC.API.Data
{
    public class CustomerAddress
    {
        [Key]
        public int AddressId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLIne2 { get; set; }
        public string City { get; set; }
        public int CustomerId { get; set; }
    }
}

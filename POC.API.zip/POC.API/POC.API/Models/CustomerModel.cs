﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using POC.API.Data;
namespace POC.API.Models
{
    public class CustomerModel
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Phone { get; set; }
        public ICollection<CustomerAddress> CustomerAddresses { get; set; }
    }
}

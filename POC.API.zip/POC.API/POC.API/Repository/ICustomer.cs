﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using POC.API.Models;
namespace POC.API.Repository
{
    public interface ICustomer
    {
        public Task<CustomerModel> GetCustomerById(int CustomerId);

    }
}

﻿using POC.API.Data;
using POC.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace POC.API.Repository
{
    public class CustomerRepository : ICustomer
    {
        private readonly PocDbContext _context;

        public CustomerRepository(PocDbContext context)
        {
            this._context = context;
        }
        public async Task<CustomerModel> GetCustomerById(int CustomerId)
        {
            //var customer = _context.Customers.Where(x => x.CustomerId == CustomerId).Select(x => new CustomerModel
            //{
            //    CustomerId = x.CustomerId,
            //    CustomerAddresses = new CustomerAddress { }
            //    CustomerName = x.CustomerName,
            //    Phone = x.Phone,



            //})

            var customer =  (from c in  _context.Customers
                            join ca in  _context.CustomerAddresses on c.CustomerId equals ca.CustomerId
                            where c.CustomerId == CustomerId
                            select new CustomerModel { CustomerId = c.CustomerId, CustomerAddresses = c.CustomerAddresses }).FirstOrDefault();

           return customer;
        }
    }
}
